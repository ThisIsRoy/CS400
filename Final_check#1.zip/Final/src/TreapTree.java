import java.util.Random;

public class TreapTree<T extends Comparable<T>> {
    private TreapNode root;

    private class TreapNode {
        private T value;
        private int priority;
        private TreapNode left;
        private TreapNode right;

        public TreapNode(T value) {
            this.value = value;

            // generate priority as random number up to 1000
            Random rand = new Random();
            this.priority = rand.nextInt(1000);
        }
    }

    public TreapTree() {
        this.root = null;
    }

    /**
     * Returns the number of nodes in the tree.
     * An empty tree has a size of 0.
     * @return tree size
     */
    public int getSize() {
        return getSize(root);
    }

    /**
     * helper function for recursively finding the size of the tree
     * @param currNode current node
     * @return size of the subtree
     */
    private int getSize(TreapNode currNode) {
        if (currNode == null) {
            return 0;
        }

        return 1 + getSize(currNode.left) + getSize(currNode.right);
    }

    /**
     * Returns the height of the tree.
     * A empty tree has height =  0. A tree with only a root has height = 1.
     * @return tree height
     */
    public int getHeight() {
        return getHeight(root);
    }

    /**
     * helper function for recursively finding the height of the tree
     * @param currNode current node
     * @return height of the subtree
     */
    private int getHeight(TreapNode currNode) {
        if (currNode == null) {
            return 0;
        }

        return 1 + Math.max(getHeight(currNode.left), getHeight(currNode.right));
    }

    /**
     * checks if tree contains a certain element
     * @param value element to check for in tree
     * @return boolean on whether element is in tree
     */
    public boolean search(T value) {
        return contains(this.root, value);
    }

    /**
     * helper function for {@link #search(T)}
     * recursively looks through the tree for element
     * @param current current node
     * @param value element to check for in tree
     * @return whether the current node contains the value
     */
    private boolean contains(TreapNode current, T value) {
        // return false if we reach end of tree
        if (current == null) {
            return false;

            // return true if we find node
        } else if (current.value == value) {
            return true;

            // continue searching via recursion
        } else if (value.compareTo(current.value) < 0) {
            return contains(current.left, value);
        } else {
            return contains(current.right, value);
        }
    }

    /**
     * insert element into correct binary position
     * @param element element to be inserted
     */
    public void insert (T element) {
        this.root = this.insert(this.root, element);
    }

    /**
     * helper function for {@link #insert(T)}
     * @param current current node
     * @param element element to be inserted
     * @return current node
     */
    private TreapNode insert(TreapNode current, T element) {
        // insert node once we reach end of tree
        if (current == null) {
            current = new TreapNode(element);

            // continue to look for end of tree via recursion
        } else if (element.compareTo(current.value) < 0 ) {
            current.left = insert(current.left, element);
        } else if (element.compareTo(current.value) > 0) {
            current.right = insert(current.right, element);
        }

        //TODO implement heap rotation logic
        return current;
    }

    /**
     * AVLTree rotate left.
     * Assumes root has a right child
     * @param root an imbalance node
     * @return TreeNode<K, V> the node for which balance has been modified
     */
    private TreapNode rotateLeft(TreapNode root) {
        TreapNode rightChild = root.right;
        // store root's right child's left child if it exists
        TreapNode rightLeftChild = rightChild.left;

        root.right = rightLeftChild;
        rightChild.left = root;

        return rightChild;
    }

    /**
     * AVLTree rotate right.
     * Assumes root has a left child
     * @param root an imbalance node
     * @return the node for which balance has been modified
     */
    private TreapNode rotateRight(TreapNode root) {
        TreapNode leftChild = root.left;
        // store root's left child's right child if it exists
        TreapNode leftRightChild = leftChild.right;

        root.left = leftRightChild;
        leftChild.right = root;

        return leftChild;
    }

    /**
     * prints tree structure
     */
    public void printSideways() {
        System.out.println("------------------------------------------");
        printSideways(root, "");
        System.out.println("------------------------------------------");
    }

    /**
     * helper function for {@link #printSideways()}
     * @param current current node
     * @param indent space between nodes
     */
    private void printSideways(TreapNode current, String indent) {
        if (current != null) {
            printSideways(current.right, indent + "    ");
            System.out.println(indent + current.value + " (" + current.priority + ")");
            printSideways(current.left, indent + "    ");
        }
    }

    public static void main(String[] args) {
        TreapTree<Integer> tree = new TreapTree<Integer>();
        tree.insert(4);
        tree.insert(7);
        tree.insert(10);
        tree.insert(12);
        tree.insert(3);
        tree.printSideways();
    }
}
