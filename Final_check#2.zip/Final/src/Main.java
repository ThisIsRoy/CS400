import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class Main extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        BorderPane root = new BorderPane();

        HBox top = new HBox(10);
        top.setAlignment(Pos.CENTER);
        Label titleLabel = new Label("Player Statistics");
        top.getChildren().add(titleLabel);
        root.setTop(top);

        // set up stage
        Scene scene = new Scene(root, 800, 500);
        primaryStage.setScene(scene);
        primaryStage.setTitle("NBA Player Statistics");
        primaryStage.show();
    }
}
